project name ------ fashion MNIST classification

The Project is involves fashion mnist dataset is a large collection of grayscale images, each 28x28 pixels in size, representing various articles of clothing and accessories. It is often used as a benchmark dataset for image classification tasks.

Requirement
--- Jupyter Notebook
----R Script

Instructions for Running the Project:
    - Ensure Python is installed on your system.
------Ensure R is installed on your system 
------Ensure jupyter notebook is installed on your system
