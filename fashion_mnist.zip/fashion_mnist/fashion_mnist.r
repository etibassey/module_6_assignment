install.packages("keras")
install.packages("ggplot2")
install.packages("caret")
install_keras()



# Importing necessary libraries
library(keras)
library(tensorflow)
library(ggplot2)
library(caret)
library(reshape2)

# Loading the Fashion MNIST Dataset
fashion_mnist <- dataset_fashion_mnist()
x_train <- fashion_mnist$train$x
y_train <- fashion_mnist$train$y
x_test <- fashion_mnist$test$x
y_test <- fashion_mnist$test$y

x_train <- x_train / 255
x_test <- x_test / 255

# Dimensions of the training data and labels respectively.
dim(x_train)
dim(x_test)
head(y_train, 5)
classes <- c("T-shirt/top", "Trouser", "Pullover", "Dress",
             "Coat", "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot")



# Building the model and training
cnn <- keras_model_sequential() %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = relu
  )
layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = "relu") %>%
  layer_dense(units = 10, activation = "softmax")

y_train_one_hot <- to_categorical(y_train, num_classes = 10)
y_test_one_hot <- to_categorical(y_test, num_classes = 10)

cnn %>% compile(
optimizer = "adam"
loss = 'categorical_crossentropy',
metrics = c('accuracy')
)

summary(cnn)

y_pred <- predict(cnn, x_test)
head(y_pred, 5)

y_classes <- apply(y_pred, 1, which.max)
head(y_classes, 5)
head(y_test, 5)

# Data Visualization
plot_sample <- function(x, y, index) {
par(mfrow = c(1, 1))
plot(as.raster(x[index, , , drop = FALSE]), main = classes[y[index + 1]])
}

# plot the sample
plot_sample(x_train, y_train, 3)

# plotting another sample
plot_sample(x_train, y_train, 9)

cat("Classification Report: \n")
confusionMatrix(as.factor(y_classes), as.factor(y_test))

# Plot training & validation accuracy values
# Note: You need to fit the model and save the history to plot accuracy
history <- cnn %>% fit(
x_train
y_train_one_hot
epochs = 10
validation_split = 0.2
)

plot(history)

# Predict labels for the test set
y_pred <- predict(cnn, x_test)
y_pred_classes <- apply(y_pred, 1, which.max)

# Compute the confusion matrix
conf_matrix <- table(Predicted = y_pred_classes, Actual = y_test)

# Plot the confusion matrix
conf_matrix_melted <- melt(conf_matrix)
ggplot(data = conf_matrix_melted, aes(x = Predicted, y = Actual)) +
geom_tile(aes(fill = value), color = "white") +
scale_fill_gradient(low = "white", high = "blue") +
geom_text(aes(label = value), color = "black") +
labs(title = "Confusion Matrix", x = "Predicted Label", y = "True Label") +
theme_minimal()
